<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  state?: string
  detail?: any
  small?: boolean
}>()

const state = computed(() => String(props.state || 'online'))

const META: Record<string, { label: string; tone: 'ok' | 'warn' | 'danger' | 'info' | 'muted' }> = {
  online: { label: '在线', tone: 'ok' },
  reconnecting: { label: '重连中', tone: 'warn' },
  no_response: { label: '心跳超时', tone: 'warn' },
  disconnected: { label: '已掉线', tone: 'danger' },
  reconnect_failed: { label: '重连失败', tone: 'danger' },
  stopped: { label: '已停止', tone: 'muted' },
}

const meta = computed(() => META[state.value] || META.online)

const reason = computed(() => {
  const d = props.detail
  if (!d || typeof d !== 'object') return ''
  return d.reason ? String(d.reason) : ''
})
</script>

<template>
  <span class="conn-badge" :class="[`conn-${meta.tone}`, small ? 'conn-small' : '']" :title="reason">
    <span class="conn-dot" />
    {{ meta.label }}
  </span>
</template>

<style scoped>
.conn-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 3px 10px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 600;
  line-height: 1.2;
  border: 1px solid transparent;
  white-space: nowrap;
  user-select: none;
}
.conn-small {
  padding: 1px 8px;
  font-size: 11px;
}
.conn-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  display: inline-block;
}
.conn-ok {
  background: rgba(34, 197, 94, 0.12);
  color: #16a34a;
  border-color: rgba(34, 197, 94, 0.22);
}
.conn-ok .conn-dot { background: #22c55e; box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.18); }
.conn-warn {
  background: rgba(245, 158, 11, 0.14);
  color: #d97706;
  border-color: rgba(245, 158, 11, 0.28);
}
.conn-warn .conn-dot { background: #f59e0b; animation: conn-pulse 1.4s ease-in-out infinite; }
.conn-danger {
  background: rgba(239, 68, 68, 0.12);
  color: #dc2626;
  border-color: rgba(239, 68, 68, 0.24);
}
.conn-danger .conn-dot { background: #ef4444; }
.conn-info {
  background: rgba(59, 130, 246, 0.12);
  color: #2563eb;
  border-color: rgba(59, 130, 246, 0.24);
}
.conn-info .conn-dot { background: #3b82f6; }
.conn-muted {
  background: rgba(107, 114, 128, 0.12);
  color: #6b7280;
  border-color: rgba(107, 114, 128, 0.22);
}
.conn-muted .conn-dot { background: #9ca3af; }
@keyframes conn-pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(1.25); }
}
</style>
