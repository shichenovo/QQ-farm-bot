# qq-farm-bot NapCat 对接版 — Linux 部署指南

> 目标：在 Linux 服务器上跑通「NapCat 扫码登录 QQ → QQ 常驻在线 → 农场 Code 自动刷新 → 掉线自动重连」。
> 代码整合自 `Siy0822/qq-farm-bot` 的 NapCat 方案（napcat 容器 + bridge + 两层自动刷新），
> 前端在面板「账号管理 → 添加账号」里提供「NapCat 扫码登录」入口。

## 架构

```
┌─────────────────────────────── Linux 服务器 ───────────────────────────────┐
│                                                                             │
│  docker compose                                                             │
│  ├── qq-farm-bot (core: Node 20, 端口 3007)                                 │
│  │     ├── Web 面板（Vue 构建产物）                                          │
│  │     ├── worker-manager（掉线检测/自动重连/400 时刷 Code 重连）              │
│  │     └── auto-code-refresh（每 60 分钟兜底刷新）                            │
│  │            │ NAPCAT_BRIDGE_SOCKET（共享卷 /run/qqfarm-napcat-bridge）     │
│  ├── napcat-farm (NapCat + QQ: Electron, 无对外端口)                         │
│  │     ├── entrypoint.sh: Xvfb + bridge 常驻                                 │
│  │     └── bridge (server.js): 按需拉起 QQ、管理扫码会话、OpenAuth 取 Code    │
│  │                                                                           │
│  └── volumes: qq-farm-napcat-data（登录态持久化）                             │
│               qq-farm-napcat-bridge（core ↔ napcat 通信）                     │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 0. 环境要求

| 依赖 | 版本 | 说明 |
|---|---|---|
| Docker | 20+ | 跑 core 与 NapCat 容器 |
| Docker Compose | 2+ | `docker compose` 子命令 |
| 内存 | 2GB+ | NapCat 里的 QQ 是 Electron，两个容器常驻约 1.5GB |

> 面板默认 `admin/admin`，对外部署后请立即改密码。

## 1. 部署

```bash
# 拉取代码（包含 napcat/ 目录与 NapCat 对接代码）
git clone https://github.com/liyangpengs/qq-farm-bot.git
cd qq-farm-bot

# 一键部署（构建 core 镜像 + NapCat 镜像 + 启动）
bash server-deploy.sh
```

等价的手动步骤：

```bash
# 只构建 NapCat 镜像（公共镜像取材，无需宿主机 QQ bundle）
docker build -f napcat/Dockerfile -t qq-farm-napcat:farm .

# 构建并启动全部服务
docker compose up -d --build

# 查看状态
docker ps --filter name=qq-farm-bot --filter name=napcat-farm
```

> 首次构建要拉 NapCat 基础镜像（约 1GB），国内网络建议先配好镜像加速。

## 2. 首次扫码登录（NapCat）

1. 浏览器打开 `http://<服务器IP>:3007`，用 `admin/admin` 登录
2. 进入 **设置 → 账号管理 → 添加账号**
3. 选择 **「NapCat 扫码登录」** 标签页
4. 用手机 QQ 扫面板上的二维码并确认
5. 扫码成功 → 面板自动拿到农场授权 Code → 自动添加账号并启动挂机
6. 之后 QQ 保持常驻在线；Code 失效时自动刷新，无需人工介入

> 二维码每 ~2 分钟自动轮换，面板会自动跟随刷新，无需手动点。

## 3. 掉线检测与自动恢复（两层机制）

| 层 | 触发 | 动作 | 代码位置 |
|---|---|---|---|
| 第一层 · 失效触发 | worker 收到游戏网关 `code 400`（登录失效） | 调 bridge `/authorize` 刷新 NapCat Code → 写回 store → 重启 worker | `core/src/runtime/worker-manager.ts`（ws_error 400 分支）+ `core/src/runtime/runtime-engine.ts`（`handleWsError400`）|
| 第二层 · 定时兜底 | 每 60 分钟（可配 `FARM_AUTO_REFRESH_MINUTES`） | 无条件刷新所有 NapCat 账号的 Code，避免失效后没被发现 | `core/src/runtime/auto-code-refresh.ts` |
| 掉线检测 | worker 心跳超时 / 主动断连 / 被踢 | 状态机 `online → disconnected/no_response → reconnecting → online`，指数退避自动重连（最多 5 次，`FARM_AUTO_RECONNECT=0` 关闭）| `core/src/runtime/connection-monitor.ts` |

两层最终都走同一个调用：bridge `POST /authorize`（`napcat-bridge-client.js`）。

## 4. 常用运维命令

```bash
# 服务总览
docker ps --format "{{.Names}}: {{.Status}}" | grep -E "napcat|qq-farm"

# 看 core 日志
docker logs -f qq-farm-bot

# 看 QQ 启动日志（排查 preload / 快速登录失败）
docker exec napcat-farm bash -lc \
  'grep -v "^[▄█ ]*$" /app/napcat-data/logs/napcat-launcher.log | tail -30'

# 手动触发一次无人值守刷新（应在秒级返回新 code）
curl -s --unix-socket /run/qqfarm-napcat-bridge/bridge.sock -X POST \
  -H "Content-Type: application/json" \
  -d '{"uin":"<QQ号>","owner":"system:manual"}' http://localhost/authorize

# 查 bridge 健康
curl -s --unix-socket /run/qqfarm-napcat-bridge/bridge.sock http://localhost/health
```

## 5. 调整刷新间隔

```bash
# 在 compose 的 qq-farm-bot 服务 environment 里加：
#   FARM_AUTO_REFRESH_MINUTES=60
# 然后：docker compose up -d
```

## 6. 换绑另一个 QQ

当前架构**只支持一个 QQ 常驻**（bridge 是全局单例）。换号必须把旧登录态清干净：

```bash
# 停服务 → 清登录态与快速登录资料 → 清面板账号 → 起服务
docker compose down
docker volume rm qq-farm-napcat-data qq-farm-napcat-bridge
# 清空 core/data/accounts.json 里的 accounts 数组
# 然后重新：bash server-deploy.sh
```

> 只清面板账号不够：常驻逻辑会从 `quick-login-profiles/` 读到旧 uin 又把老号拉起来，
> 新号的码扫不上（会被判定「当前扫码登录的是 QQ A，与目标账号 B 不一致」）。

## 7. 已知事项

- **单账号限制**：bridge 单例 + 租约，同一时刻只支持一个 QQ 常驻。多账号需每个 QQ 独立容器（进阶改造）。
- **登录态持久化**：`qq-farm-napcat-data` 卷保存登录态与快速登录资料，容器重建不丢；
  扫码一次后，之后的自动恢复（快速登录）都走得通。
- **QQ 长时间离线且快速登录资料失效**：仍需手动扫码一次，扫码后资料重新落盘。
- 面板「输入 Code 登录」「微信扫码登录」仍可用（NapCat 未就绪时兜底）。
