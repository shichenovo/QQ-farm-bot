#!/bin/bash
# 换绑另一个 QQ（单账号架构）。
#
# 单实例架构下换号，必须先把旧 QQ 的登录态彻底清干净，否则：
#   1. 常驻逻辑会从 quick-login-profiles 里读到旧 uin，开机又把老号拉起来，
#      新号的码根本扫不上（扫了也会被判定成「账号不一致」）；
#   2. 面板里残留的旧账号仍带着旧 Code，worker 启动时去刷新就会报
#      「NapCat QQ 与目标农场账号不匹配」。
#
# 用法：bash switch-qq.sh
# 跑完去面板扫码登录新 QQ 即可，新号会自动常驻并开启 Code 自动刷新。

set -u

ROOT_DIR="/workspace/qq-farm-bot"
DATA_DIR="/srv/qqfarm-napcat-data"
ACCOUNTS="$ROOT_DIR/core/data/accounts.json"

echo "==> 1/4 停止服务"
# 中括号规避自匹配：pkill -f 会连执行它的 shell 一起杀（命令行里含目标字符串）
pkill -f "keepaliv[e].sh" 2>/dev/null
pkill -f "node clien[t].js" 2>/dev/null
docker rm -f napcat-farm >/dev/null 2>&1
sleep 2
echo "    已停止 keepalive / core / NapCat 容器"

echo "==> 2/4 清除旧 QQ 的登录态与快速登录资料"
rm -rf "${DATA_DIR:?}/quick-login-profiles"/*
rm -rf "${DATA_DIR:?}/session-home"
echo "    已清空 quick-login-profiles/ 与 session-home/"

echo "==> 3/4 清空面板里的农场账号（旧 Code 随旧 QQ 一起作废）"
if [ -f "$ACCOUNTS" ]; then
  python3 - "$ACCOUNTS" <<'PY'
import json, sys
path = sys.argv[1]
with open(path, encoding='utf-8') as f:
    data = json.load(f)
removed = len(data.get('accounts') or [])
data['accounts'] = []
with open(path, 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
print(f"    已清除 {removed} 个账号")
PY
else
  echo "    未找到 accounts.json，跳过"
fi

echo "==> 4/4 启动服务"
cd "$ROOT_DIR" || exit 1
setsid nohup bash keepalive.sh >> /tmp/keepalive.log 2>&1 < /dev/null &
sleep 20

echo
echo "服务已重启："
docker ps --format "    NapCat 容器: {{.Status}}" 2>/dev/null | grep napcat
URL="$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /tmp/cf.log 2>/dev/null | tail -1)"
if [ -n "$URL" ]; then
  echo "    面板地址: $URL"
  echo
  echo "现在去面板「账号管理 → 添加账号」扫新 QQ 的码。"
  echo "扫码后新号会自动常驻在线，并开启 Code 自动刷新。"
else
  echo "    面板地址: 稍等几秒后从 /tmp/cf.log 里取 trycloudflare.com 链接"
  echo "    （隧道刚重启，公网地址可能要几秒才就绪）"
fi
