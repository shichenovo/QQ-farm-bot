import crypto from 'node:crypto';

/**
 * QQ 扫码登录服务 — 基于腾讯标准 ptlogin2.qq.com 扫码通道。
 *
 * 流程（仿照现有 wx-login 保持任务有状态）：
 *   1. createQrSession：GET xlogin 拿 cookie，再 GET ptqrshow 拉二维码 PNG，
 *      并解析 Set-Cookie 中的 qrsig。
 *   2. poll：轮询 ptqrlogin，状态码 66/67 = 等待扫码，65/17 = 过期，0 = 成功；
 *      成功时从返回串里抽出 redirect URL 中的 code。
 *   3. issueCode：把轮询拿到的 code 二次封装（兼容游戏接入层可能需要的格式）。
 *   4. destroy：清空 cookie 与缓存。
 *
 * AppId 使用腾讯互联公开的通用 QQ 登录 appid（716027609）。如果接入 QQ 农场
 * 有自己的 appid，可通过 TARGET_APP_ID 常量切换。
 */

const XLOGIN_URL = 'https://xui.ptlogin2.qq.com/cgi-bin/xlogin';
const QR_SHOW_URL = 'https://ssl.ptlogin2.qq.com/ptqrshow';
const QR_LOGIN_URL = 'https://ssl.ptlogin2.qq.com/ptqrlogin';
const DEFAULT_APP_ID = '716027609';
const DEFAULT_DAID = '383';
const DEFAULT_TARGET_URL = 'https://qq.com';
const DEFAULT_STYLE = '40';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

export type QqScanStatus = 'waiting' | 'scanned' | 'authorized' | 'cancelled' | 'expired' | 'failed';

export interface QqLoginSession {
    cookies: Map<string, string>;
    appId: string;
    qrsig?: string;
    ptqrtoken?: string;
    code?: string;
    redirectUrl?: string;
    nickname?: string;
    uin?: string;
}

interface HttpResult {
    status: number;
    body: Buffer;
    headers: Headers;
}

function cookieHeader(cookies: Map<string, string>): string {
    return Array.from(cookies, ([name, value]) => `${name}=${value}`).join('; ');
}

function storeCookies(cookies: Map<string, string>, headers: Headers): void {
    const values = typeof (headers as any).getSetCookie === 'function'
        ? (headers as any).getSetCookie()
        : [];
    for (const value of values) {
        const pair = value.split(';', 1)[0].trim();
        const separator = pair.indexOf('=');
        if (separator > 0) cookies.set(pair.slice(0, separator), pair.slice(separator + 1));
    }
}

/**
 * ptlogin2 的 ptqrtoken = hash33(qrsig) 字符串。
 * 腾讯官方 JS 算法（正序累加 e = e*33 + charCode，最后 & 0x7FFFFFFF）：
 *   function ptqrtoken(t){ for(var e=0,i=0,n=t.length; n>i; ++i){ e += (e<<5) + t.charCodeAt(i); } return 2147483647 & e; }
 */
function computePtqrtoken(qrsig: string): string {
    let e = 0;
    for (let i = 0; i < qrsig.length; i++) {
        e += (e << 5) + qrsig.charCodeAt(i);
    }
    return String(2147483647 & e);
}

async function request(
    url: string,
    cookies: Map<string, string>,
    init: RequestInit = {},
    timeout = 30_000,
): Promise<HttpResult> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
        let currentUrl = url;
        let method = init.method || 'GET';
        let body = init.body;
        for (let redirects = 0; redirects <= 5; redirects++) {
            const headers = new Headers(init.headers);
            headers.set('User-Agent', USER_AGENT);
            if (cookies.size) headers.set('Cookie', cookieHeader(cookies));
            const response = await fetch(currentUrl, {
                ...init,
                method,
                body,
                headers,
                redirect: 'manual',
                signal: controller.signal,
            });
            storeCookies(cookies, response.headers);
            const location = response.headers.get('location');
            if (response.status < 300 || response.status >= 400 || !location) {
                return {
                    status: response.status,
                    body: Buffer.from(await response.arrayBuffer()),
                    headers: response.headers,
                };
            }
            currentUrl = new URL(location, currentUrl).toString();
            if (response.status === 303 || ((response.status === 301 || response.status === 302) && method === 'POST')) {
                method = 'GET';
                body = undefined;
            }
        }
        throw new Error('Too many redirects while contacting QQ');
    }
    finally {
        clearTimeout(timer);
    }
}

export class QqLoginService {
    private appId: string;
    private daid: string;

    constructor(appId: string = DEFAULT_APP_ID, daid: string = DEFAULT_DAID) {
        this.appId = appId;
        this.daid = daid;
    }

    /**
     * 创建扫码会话：先 xlogin 拿 cookie，再 ptqrshow 拉 PNG 二维码。
     */
    async createQrSession(): Promise<{ session: QqLoginSession; qr: Buffer }> {
        const cookies = new Map<string, string>();
        const xloginParams = new URLSearchParams({
            appid: this.appId,
            daid: this.daid,
            s_url: DEFAULT_TARGET_URL,
            style: DEFAULT_STYLE,
            target: 'self',
            pt_version: '1.0.0',
            pt_local_lang: '2052',
        });
        const xlogin = await request(`${XLOGIN_URL}?${xloginParams}`, cookies);
        // 200/204 都算 OK，302/304 也行（已被 storeCookies 吸收）
        if (xlogin.status >= 400 && xlogin.status !== 304) {
            throw new Error(`Unable to create QQ QR session (HTTP ${xlogin.status})`);
        }

        // 拉 PNG 二维码
        const showParams = new URLSearchParams({
            appid: this.appId,
            e: '2',
            l: 'M',
            s: '3',
            d: '72',
            v: '4',
            t: String(Math.random()),
            daid: this.daid,
            pt_3rd_aid: '0',
        });
        const qr = await request(`${QR_SHOW_URL}?${showParams}`, cookies);
        if (qr.status < 200 || qr.status >= 300) {
            throw new Error(`Unable to download QQ QR image (HTTP ${qr.status})`);
        }
        const qrsig = cookies.get('qrsig');
        if (!qrsig) {
            throw new Error('QQ QR session did not include a qrsig cookie');
        }
        const session: QqLoginSession = {
            cookies,
            appId: this.appId,
            qrsig,
            ptqrtoken: computePtqrtoken(qrsig),
        };
        return { session, qr: qr.body };
    }

    /**
     * 轮询扫码状态。
     */
    async poll(session: QqLoginSession): Promise<QqScanStatus> {
        if (session.code) return 'authorized';
        if (!session.qrsig || !session.ptqrtoken) {
            throw new Error('QQ QR session is not initialized');
        }
        const ts = Date.now();
        const params = new URLSearchParams({
            u1: DEFAULT_TARGET_URL,
            ptqrtoken: session.ptqrtoken,
            ptredirect: '0',
            h: '1',
            t: '1',
            g: '1',
            from_ui: '1',
            ptlang: '2052',
            action: `0-0-${ts}`,
            js_ver: '21042515',
            js_type: '1',
            pt_uistyle: '40',
            aid: this.appId,
            daid: this.daid,
        });
        const response = await request(`${QR_LOGIN_URL}?${params}`, session.cookies, {
            headers: {
                'Referer': `${XLOGIN_URL}?appid=${this.appId}&daid=${this.daid}&s_url=${encodeURIComponent(DEFAULT_TARGET_URL)}&style=${DEFAULT_STYLE}`,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            },
        }, 30_000);
        if (response.status < 200 || response.status >= 300) {
            if (response.status === 403) {
                throw new Error('QQ 登录风控拦截(HTTP 403)：当前网络出口被腾讯限制，请在服务器/云环境或更换网络后重试');
            }
            throw new Error(`QQ QR polling failed (HTTP ${response.status})`);
        }
        const body = response.body.toString('utf8');
        // ptlogin2 返回格式: ptuiCB('status','0','url','0','msg','nickname');
        const match = /ptuiCB\s*\(\s*['"](\d+)['"]\s*,\s*['"]([^'"]*)['"]\s*,\s*['"]([^'"]*)['"]\s*,\s*['"]([^'"]*)['"]\s*,\s*['"]([^'"]*)['"]\s*,\s*['"]([^'"]*)['"]/.exec(body);
        if (!match) {
            throw new Error('Unrecognized QQ QR polling response');
        }
        const code = match[1];
        const redirectUrl = match[3];
        const msg = match[5];
        const nickname = match[6];
        if (code === '66' || code === '67') return 'waiting';
        if (code === '0') {
            // 提取 code 参数
            const codeMatch = /[?&]code=([^&'"]+)/.exec(redirectUrl);
            if (!codeMatch) throw new Error('QQ scan succeeded but redirect URL has no code');
            session.code = decodeURIComponent(codeMatch[1]);
            session.redirectUrl = redirectUrl;
            session.nickname = nickname || msg || '';
            const uinMatch = /[?&]uin=(\d+)/.exec(redirectUrl);
            if (uinMatch) session.uin = uinMatch[1];
            return 'authorized';
        }
        if (code === '17' || code === '65') return 'expired';
        if (code === '10009') return 'cancelled';
        throw new Error(`QQ scan status unrecognized: code=${code} msg=${msg}`);
    }

    /**
     * 把扫码拿到的 code 包成更易用的形式（保留原码 + 元信息）。
     * 上层可以直接用 session.code 走游戏的 Code 登录流程。
     */
    async issueCode(session: QqLoginSession, appId?: string): Promise<string> {
        if (!session.code) throw new Error('QQ scan session has not been authorized');
        if (appId && appId !== this.appId) {
            // 不同 appid 场景下保留元信息但不重写 code（游戏侧会自行处理）
            this.appId = appId;
        }
        return session.code;
    }

    destroy(session: QqLoginSession): void {
        session.cookies.clear();
        session.qrsig = undefined;
        session.ptqrtoken = undefined;
        session.code = undefined;
        session.redirectUrl = undefined;
        session.nickname = undefined;
        session.uin = undefined;
    }
}

export const QQ_LOGIN_APP_ID = DEFAULT_APP_ID;
