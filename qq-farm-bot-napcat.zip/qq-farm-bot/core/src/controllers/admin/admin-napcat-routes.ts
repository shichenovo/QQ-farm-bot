/**
 * NapCat 扫码登录路由（适配 liyangpengs 单管理员版）。
 *
 * 逻辑移植自 Siy0822/qq-farm-bot 的 admin-napcat-routes.js，改动：
 *   - 挂载签名改为 mountAdminNapcatRoutes(app, ctx)（与本项目其它路由一致）
 *   - 鉴权走本项目 createAuthRequired(ctx)
 *   - 单管理员：owner 用 token 前缀，不做多用户权限判断
 *   - provider 接口映射到本项目 data-provider
 */

export {};
const { createAuthRequired } = require('./middleware');
const store = require('../../models/store');

const {
    authorizeNapCatFarm,
    checkNapCatBridge,
    getNapCatLoginStatus,
    getNapCatQrCode,
    getNapCatQrImage,
    reclaimNapCatScanLease,
    refreshNapCatQrCode,
    releaseNapCatScanLease,
} = require('../../services/napcat-bridge-client');

const NAPCAT_FARM_APP_ID = '1112386029';

function getAccountList(ctx: any): any[] {
    try {
        if (ctx.provider && typeof ctx.provider.getAccounts === 'function') {
            const data = ctx.provider.getAccounts();
            if (Array.isArray(data?.accounts)) return data.accounts;
        }
    } catch {}
    const data = store.getAccounts ? store.getAccounts() : { accounts: [] };
    return Array.isArray(data.accounts) ? data.accounts : [];
}

// 单管理员版本：owner 用 token 前缀（稳定且能区分面板会话）。
// 后台无人值守任务传 system:*（见 auto-code-refresh）。
function scanOwner(req: any): string {
    const token = String(req.adminToken || '').trim();
    return token ? `token:${token.slice(0, 12)}` : '';
}

// 租约冲突（409）不是故障，要原样把等待提示透给前端，别糊成 502。
function sendBridgeError(res: any, error: any): void {
    if (error && error.busy) {
        return res.status(409).json({
            ok: false,
            error: error.message,
            busy: true,
            retryAfterMs: error.retryAfterMs || 0,
        });
    }
    return res.status(502).json({ ok: false, error: error.message });
}

function mountAdminNapcatRoutes(app: any, ctx: any): void {
    app.use('/api/qr', createAuthRequired(ctx));

    app.get('/api/qr/napcat-login', async (req: any, res: any) => {
        try {
            const data = await getNapCatQrCode(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });

    app.post('/api/qr/napcat-refresh', async (req: any, res: any) => {
        try {
            const data = await refreshNapCatQrCode(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });

    // 前端 2s 轮询"扫没扫"走这个无副作用接口，不能用 /napcat-login：
    // 后者会在二维码过期时重启 QQ，把用户正在扫的会话反复打死。
    app.get('/api/qr/napcat-poll', async (req: any, res: any) => {
        try {
            const data = await getNapCatLoginStatus(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });

    // 无副作用：只读当前 qrcode.png。NapCat 自己每 ~122s 重写该文件轮换二维码，
    // 前端靠 /napcat-poll 的 updatedAt 变化拉这个接口跟随换图，全程不碰进程。
    app.get('/api/qr/napcat-image', async (req: any, res: any) => {
        try {
            const data = await getNapCatQrImage(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });

    app.get('/api/qr/napcat-status', async (_req: any, res: any) => {
        try {
            await checkNapCatBridge();
            res.json({ ok: true, data: { bridge: 'reachable', appId: NAPCAT_FARM_APP_ID } });
        } catch (error: any) {
            res.status(503).json({ ok: false, error: error.message });
        }
    });

    // 关弹窗/关页面时主动交回扫码租约，不用等空闲超时，下一个人立刻能扫。
    app.post('/api/qr/napcat-release', async (req: any, res: any) => {
        try {
            const data = await releaseNapCatScanLease(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error: any) {
            res.json({ ok: true, data: { released: false, reason: error.message } });
        }
    });

    // 页面从后台恢复时软重新占用（不换码、不重启会话）。
    app.post('/api/qr/napcat-reclaim', async (req: any, res: any) => {
        try {
            const data = await reclaimNapCatScanLease(scanOwner(req));
            res.json({ ok: true, data });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });

    app.post('/api/qr/napcat-farm-code', async (req: any, res: any) => {
        try {
            const body = req.body && typeof req.body === 'object' ? req.body : {};
            const accountId = String(body.accountId || body.id || '').trim();
            const allAccounts = getAccountList(ctx);
            const existing = accountId
                ? allAccounts.find((account: any) => String(account.id) === accountId)
                : null;
            if (accountId && !existing) return res.status(404).json({ ok: false, error: '账号不存在' });
            if (existing && String(existing.platform || 'qq').toLowerCase() !== 'qq') {
                return res.status(400).json({ ok: false, error: 'QQ 授权不能覆盖微信账号' });
            }

            const data = await authorizeNapCatFarm(
                (existing && (existing.uin || existing.qq)) || '',
                scanOwner(req),
            );
            const authorization = data.authorization || {};
            const profile = data.profile || {};
            if (!authorization.code) throw new Error('QQ 授权未返回农场 Code');
            const boundOpenId = String(existing && (existing.openID || existing.openid) || '').trim();
            if (existing && boundOpenId && authorization.openID && authorization.openID !== boundOpenId) {
                throw new Error('当前 QQ 与目标农场账号不匹配');
            }

            const payload: any = {
                ...(existing || {}),
                ...(existing ? { id: accountId } : {}),
                name: existing
                    ? String(body.name ?? existing.name ?? '').trim()
                    : String(body.name || '').trim(),
                code: authorization.code,
                openID: authorization.openID || boundOpenId,
                openid: authorization.openID || boundOpenId,
                uin: profile.uin || existing?.uin || '',
                qq: profile.uin || existing?.qq || '',
                avatar: profile.avatar || existing?.avatar || '',
                platform: 'qq',
                loginType: 'napcat_open_auth',
            };
            const wasRunning = existing && ctx.provider.isAccountRunning
                ? ctx.provider.isAccountRunning(accountId)
                : false;
            const saved = store.addOrUpdateAccount(payload);
            const updated = existing
                ? saved.accounts.find((account: any) => String(account.id) === accountId)
                : saved.accounts.at(-1);
            if (!updated) throw new Error('保存 QQ 农场账号失败');

            // 扫码链路刚把全新 Code 写进 store。本项目 startAccount 直接拉 worker，
            // 重复授权的问题由桥接侧的 system:* / token:* 租约与幂等兜底。
            let startAction = 'none';
            if (wasRunning && ctx.provider.restartAccount) {
                ctx.provider.restartAccount(updated.id);
                startAction = 'restart';
            } else if (ctx.provider.startAccount) {
                // 已存在但当前停止的账号也要拉起（Code 过期停掉账号正是用户来扫码的常见原因）。
                ctx.provider.startAccount(updated.id);
                startAction = 'start';
            }
            if (ctx.provider.addAccountLog) {
                const startNote = startAction === 'restart'
                    ? '，已重启账号'
                    : (startAction === 'start' ? '，已自动启动账号' : '');
                ctx.provider.addAccountLog(
                    existing ? 'update' : 'add',
                    `通过 QQ 扫码${existing ? '更新' : '添加'}农场授权${startNote}`,
                    updated.id,
                    updated.name || '',
                );
            }
            res.json({
                ok: true,
                data: {
                    success: true,
                    account: { id: updated.id, name: updated.name, platform: 'qq', loginType: 'napcat_open_auth' },
                    authorization: { appId: NAPCAT_FARM_APP_ID, source: 'NapCat OpenAuth', expiresAt: authorization.expiresAt || null },
                },
            });
        } catch (error) {
            sendBridgeError(res, error);
        }
    });
}

module.exports = { mountAdminNapcatRoutes };
