import crypto from 'node:crypto';
import type { Application, Request, Response } from 'express';
import type { AdminContext } from './context';
import { QqLoginService, QQ_LOGIN_APP_ID } from '../../services/qq-login/service';
import type { QqLoginSession, QqScanStatus } from '../../services/qq-login/service';

export {};

const { createAuthRequired } = require('./middleware');

const TASK_TTL_MS = 110_000;
type Status = QqScanStatus;
interface Task {
    id: string;
    createdAt: number;
    status: Status;
    session: QqLoginSession;
    qr: Buffer;
    appId: string;
}
const tasks = new Map<string, Task>();
const qqLogin = new QqLoginService();

function destroy(task: Task): void {
    qqLogin.destroy(task.session);
    tasks.delete(task.id);
}

function publicTask(task: Task) {
    return {
        task_id: task.id,
        app_id: task.appId,
        status: task.status,
        expires_at: Math.floor((task.createdAt + TASK_TTL_MS) / 1000),
        uin: task.session.uin || '',
        nickname: task.session.nickname || '',
    };
}

function findTask(req: Request, res: Response): Task | null {
    const task = tasks.get(String(req.params.taskId || ''));
    if (!task || Date.now() - task.createdAt > TASK_TTL_MS) {
        if (task) destroy(task);
        res.status(404).json({ ok: false, error: 'QQ login task not found or expired' });
        return null;
    }
    return task;
}

async function createTask(appId: string): Promise<Task> {
    const { session, qr } = await qqLogin.createQrSession();
    const task: Task = {
        id: crypto.randomBytes(32).toString('hex'),
        createdAt: Date.now(),
        status: 'waiting',
        session,
        qr,
        appId,
    };
    tasks.set(task.id, task);
    return task;
}

async function poll(task: Task): Promise<void> {
    if (task.status === 'authorized') return;
    task.status = await qqLogin.poll(task.session);
}

async function consumeCode(task: Task): Promise<void> {
    if (task.status !== 'authorized') throw new Error('QQ scan is not authorized yet');
    await qqLogin.issueCode(task.session, task.appId);
}

function mountQqLoginRoutes(app: Application, ctx: AdminContext): void {
    app.use('/api/qq-login', createAuthRequired(ctx));

    app.post('/api/qq-login/tasks', async (req, res) => {
        const body = (req.body && typeof req.body === 'object') ? req.body : {};
        const requested = String(body.app_id || QQ_LOGIN_APP_ID);
        if (requested !== QQ_LOGIN_APP_ID) {
            return res.status(400).json({ ok: false, error: 'Unsupported app_id' });
        }
        try {
            const task = await createTask(requested);
            res.json({
                ok: true,
                data: { ...publicTask(task), qr_url: `/api/qq-login/tasks/${task.id}/qr` },
            });
        }
        catch (error: any) {
            res.status(502).json({ ok: false, error: error.message });
        }
    });

    app.get('/api/qq-login/tasks/:taskId/qr', (req, res) => {
        const task = findTask(req, res);
        if (task) res.type('png').send(task.qr);
    });

    app.delete('/api/qq-login/tasks/:taskId', (req, res) => {
        const task = tasks.get(String(req.params.taskId || ''));
        if (!task) return res.status(404).json({ ok: false, error: 'QQ login task not found' });
        destroy(task);
        return res.json({ ok: true });
    });

    app.get('/api/qq-login/tasks/:taskId/status', async (req, res) => {
        const task = findTask(req, res);
        if (!task) return;
        try {
            await poll(task);
            const data = publicTask(task);
            if (task.status === 'cancelled' || task.status === 'expired' || task.status === 'failed') {
                destroy(task);
            }
            res.json({ ok: true, data });
        }
        catch (error: any) {
            task.status = 'failed';
            destroy(task);
            res.status(502).json({ ok: false, error: error.message });
        }
    });

    app.post('/api/qq-login/tasks/:taskId/code', async (req, res) => {
        const task = findTask(req, res);
        if (!task) return;
        try {
            await consumeCode(task);
            const data = {
                app_id: task.appId,
                uin: task.session.uin || '',
                nickname: task.session.nickname || '',
                code: task.session.code || '',
                redirect_url: task.session.redirectUrl || '',
                err_msg: 'login:ok',
            };
            destroy(task);
            res.json({ ok: true, data });
        }
        catch (error: any) {
            task.status = 'failed';
            destroy(task);
            res.status(502).json({ ok: false, error: error.message });
        }
    });
}

// 暴露给其它模块（如定时清理）
function sweepExpiredTasks(): number {
    const now = Date.now();
    let removed = 0;
    for (const [id, task] of tasks) {
        if (now - task.createdAt > TASK_TTL_MS) {
            destroy(task);
            removed += 1;
        }
    }
    return removed;
}

module.exports = {
    mountQqLoginRoutes,
    sweepExpiredTasks,
};
