export {};
const { fork } = require('node:child_process');
const path = require('node:path');
const { Worker } = require('node:worker_threads');
const store = require('../models/store');
const { updateRuntimeConfig, getRuntimeConfig, getDefaultSystemConfig } = require('../config/config');
const { sendPushooMessage } = require('../services/push');
const { createDataProvider } = require('./data-provider');
const { createReloginReminderService } = require('./relogin-reminder');
const { createRuntimeState } = require('./runtime-state');
const { createWorkerManager } = require('./worker-manager');
const { createConnectionMonitor } = require('./connection-monitor');
const { createAutoCodeRefreshService } = require('./auto-code-refresh');

const OPERATION_KEYS = ['harvest', 'farming', 'fertilize', 'plant', 'steal', 'helpFarming', 'taskClaim', 'sell', 'upgrade'];

interface RuntimeEngineOptions {
    processRef?: any;
    mainEntryPath?: string;
    workerScriptPath?: string;
    runtimeMode?: string;
    onStatusSync?: (accountId: string, status: any, accountName?: string) => void;
    onLog?: (entry: any, accountId?: string, accountName?: string) => void;
    onAccountLog?: (entry: any) => void;
    onConnectionState?: (accountId: string, accountName: string, state: string, detail: any) => void;
    startAdminServer?: (dataProvider: any) => void;
}

function createRuntimeEngine(options: RuntimeEngineOptions = {}) {
    const processRef = options.processRef || process;
    // Detect if running from source (tsx) or compiled (node)
    const isRunningFromSource = __dirname.includes(`${path.sep}src${path.sep}`);
    const fileExt = isRunningFromSource ? '.ts' : '.js';
    const mainEntryPath = options.mainEntryPath || path.join(__dirname, `../../client${fileExt}`);
    const workerScriptPath = options.workerScriptPath || path.join(__dirname, `../core/worker${fileExt}`);
    const runtimeMode = String(options.runtimeMode || processRef.env.FARM_RUNTIME_MODE || 'thread').toLowerCase();
    const onStatusSync = typeof options.onStatusSync === 'function' ? options.onStatusSync : null;
    const onLog = typeof options.onLog === 'function' ? options.onLog : null;
    const onAccountLog = typeof options.onAccountLog === 'function' ? options.onAccountLog : null;
    const onConnectionState = typeof options.onConnectionState === 'function' ? options.onConnectionState : null;
    const startAdminServer = typeof options.startAdminServer === 'function' ? options.startAdminServer : null;

    const runtimeState = createRuntimeState({
        store,
        operationKeys: OPERATION_KEYS,
    });
    const {
        workers,
        globalLogs: GLOBAL_LOGS,
        accountLogs: ACCOUNT_LOGS,
        runtimeEvents,
        nextConfigRevision,
        buildConfigSnapshotForAccount,
        log,
        addAccountLog,
        normalizeStatusForPanel,
        buildDefaultStatus,
        filterLogs,
    } = runtimeState;

    const reloginReminder = createReloginReminderService({
        store,
        sendPushooMessage,
        log,
    });

    const {
        getOfflineAutoDeleteMs,
        triggerOfflineReminder,
        sendConfiguredPush,
    } = reloginReminder;

    // 提前声明以避免 TDZ（worker-manager 的回调在 connectionMonitor 之前注册）
    let connectionMonitor: any = null;

    const { startWorker, stopWorker, restartWorker, callWorkerApi, getConnectionState, getAllConnectionStates } = createWorkerManager({
        fork,
        WorkerThread: Worker,
        runtimeMode,
        processRef,
        mainEntryPath,
        workerScriptPath,
        workers,
        globalLogs: GLOBAL_LOGS,
        log,
        addAccountLog,
        normalizeStatusForPanel,
        buildConfigSnapshotForAccount,
        getOfflineAutoDeleteMs,
        triggerOfflineReminder,
        sendConfiguredPush,
        addOrUpdateAccount: store.addOrUpdateAccount,
        deleteAccount: store.deleteAccount,
        onStatusSync: (accountId: string, status: any, accountName?: string) => {
            runtimeEvents.emit('status', { accountId, status, accountName });
            if (onStatusSync) onStatusSync(accountId, status, accountName);
        },
        onWorkerLog: (entry: any, accountId: string, accountName?: string) => {
            runtimeEvents.emit('worker_log', { entry, accountId, accountName });
            if (onLog) onLog(entry, accountId, accountName);
        },
        onMonitorRecordStatusSync: (accountId: string, status: any) => {
            connectionMonitor.recordStatusSync(accountId, status);
        },
        onMonitorRecordDisconnected: (accountId: string, detail: any) => {
            connectionMonitor.recordDisconnected(accountId, detail);
        },
        onMonitorRecordKicked: (accountId: string, detail: any) => {
            connectionMonitor.recordKicked(accountId, detail);
        },
        onMonitorMarkWorkerStarted: (accountId: string) => {
            connectionMonitor.markWorkerStarted(accountId);
        },
        onMonitorMarkManualStop: (accountId: string) => {
            connectionMonitor.markManualStop(accountId);
        },
        onWsError400: (accountId: string) => handleWsError400(accountId),
    });

    // 连接监控：心跳巡检 + 自动重连
    connectionMonitor = createConnectionMonitor({
        workers,
        restartWorker: (account: any) => restartWorker(account),
        getAccount: (accountId: string) => {
            try {
                const all = store.getAccounts();
                return (all && all.accounts) ? all.accounts.find((a: any) => String(a.id) === String(accountId)) : null;
            } catch {
                return null;
            }
        },
        callWorkerApi: (accountId: string, method: string, ...args: any[]) => callWorkerApi(accountId, method, ...args),
        log,
        addAccountLog,
        triggerOfflineReminder,
        onStateChange: (accountId, accountName, state, detail) => {
            runtimeEvents.emit('connection_state', { accountId, accountName, state, detail });
            if (onConnectionState) onConnectionState(accountId, accountName, state, detail);
        },
        options: {
            autoReconnect: processRef.env.FARM_AUTO_RECONNECT !== '0',
            heartbeatIntervalMs: Number(processRef.env.FARM_MONITOR_INTERVAL_MS) || 5_000,
            heartbeatStaleMs: Number(processRef.env.FARM_MONITOR_STALE_MS) || 15_000,
            noResponseTimeoutMs: Number(processRef.env.FARM_MONITOR_NO_RESPONSE_MS) || 30_000,
            maxAutoReconnectAttempts: Number(processRef.env.FARM_MONITOR_MAX_RETRIES) || 5,
            baseBackoffMs: Number(processRef.env.FARM_MONITOR_BACKOFF_MS) || 3_000,
        },
    });
    // Code 自动刷新（NapCat 定时兜底）：每 60 分钟对 napcat_open_auth 账号换新 Code 并重启 worker
    const autoCodeRefresh = createAutoCodeRefreshService({
        store,
        log,
        addAccountLog,
        restartWorker: (account: any) => restartWorker(account),
        getAccounts: store.getAccounts,
    });

    // 第一层失效触发：worker 报 ws_error 400（登录失效）→ 刷新 NapCat Code → 重启 worker
    async function handleWsError400(accountId: string): Promise<void> {
        const all = store.getAccounts();
        const account = (all && all.accounts) ? all.accounts.find((a: any) => String(a.id) === String(accountId)) : null;
        if (!account) return;
        const isNapCatQq = String(account.platform || 'qq').toLowerCase() === 'qq'
            && String(account.loginType || '') === 'napcat_open_auth'
            && String(account.uin || account.qq || '').trim() !== '';
        if (!isNapCatQq) return;
        log('系统', `账号 ${account.name} 登录失效(400)，开始刷新 NapCat Code 并重连`, {
            accountId: String(accountId),
            accountName: account.name || '',
        });
        await autoCodeRefresh.refreshAccountCode(String(accountId), 'ws_400');
    }

    const dataProvider = createDataProvider({
        workers,
        globalLogs: GLOBAL_LOGS,
        accountLogs: ACCOUNT_LOGS,
        store,
        getAccounts: store.getAccounts,
        callWorkerApi,
        buildDefaultStatus,
        normalizeStatusForPanel,
        filterLogs,
        addAccountLog,
        nextConfigRevision,
        broadcastConfigToWorkers,
        buildConfigSnapshotForAccount,
        broadcastGameConfigReload,
        startWorker,
        stopWorker,
        restartWorker,
        getConnectionState,
        getAllConnectionStates,
    });

    runtimeEvents.on('log', (entry: any) => {
        if (onLog) onLog(entry, entry && entry.accountId ? entry.accountId : '', entry && entry.accountName ? entry.accountName : '');
    });
    runtimeEvents.on('account_log', (entry: any) => {
        if (onAccountLog) onAccountLog(entry);
    });

    function broadcastConfigToWorkers(targetAccountId = ''): void {
        const targetId = String(targetAccountId || '').trim();
        for (const [accId, worker] of Object.entries(workers)) {
            if (targetId && String(accId) !== targetId) continue;
            const snapshot = buildConfigSnapshotForAccount(accId);
            try {
                (worker as any).process.send({ type: 'config_sync', config: snapshot });
            } catch {
                // ignore IPC failures for exited workers
            }
        }
    }

    function broadcastGameConfigReload(): void {
        for (const worker of Object.values(workers)) {
            try {
                (worker as any).process.send({ type: 'reload_config' });
            } catch {
                // ignore IPC failures for exited workers
            }
        }
    }

    function startAllAccounts(): void {
        const accounts = (store.getAccounts().accounts || []);
        if (accounts.length > 0) {
            log('系统', `发现 ${accounts.length} 个账号，正在启动...`);
            accounts.forEach((acc: any) => startWorker(acc));
        } else {
            log('系统', '未发现账号，请访问管理面板添加账号');
        }
    }

    async function start(options: { startAdminServer?: boolean; autoStartAccounts?: boolean } = {}): Promise<void> {
        const shouldStartAdminServer = options.startAdminServer !== false;
        const shouldAutoStartAccounts = options.autoStartAccounts !== false;

        const savedSystemConfig = store.getSystemConfig();
        if (savedSystemConfig) {
            updateRuntimeConfig(savedSystemConfig);
            log('系统', `已加载系统配置: serverUrl=${savedSystemConfig.serverUrl}, clientVersion=${savedSystemConfig.clientVersion}, platform=${savedSystemConfig.platform}`);
        }

        // 启动连接监控（心跳 + 自动重连）
        connectionMonitor.start();
        // 启动 NapCat Code 自动刷新定时器（每 60 分钟兜底）
        autoCodeRefresh.rescheduleAll();

        if (shouldStartAdminServer && startAdminServer) {
            startAdminServer(dataProvider);
        }

        if (shouldAutoStartAccounts) {
            startAllAccounts();
        }
    }

    function stopAllAccounts(): void {
        for (const accountId of Object.keys(workers)) {
            stopWorker(accountId);
        }
    }

    function getMergedConnectionStates() {
        const fromMonitor = connectionMonitor.getAllStates() as Record<string, any>;
        const fromWorker = getAllConnectionStates() as Record<string, { state: string; detail: any; name?: string }>;
        // 合并：worker 端最新值优先（它知道刚发生的 status_sync）
        for (const [id, s] of Object.entries(fromWorker)) {
            fromMonitor[id] = { ...(fromMonitor[id] || {}), state: s.state, detail: s.detail, name: s.name };
        }
        return fromMonitor;
    }

    return {
        store,
        runtimeEvents,
        workers,
        dataProvider,
        connectionMonitor,
        autoCodeRefresh,
        start,
        startAllAccounts,
        stopAllAccounts,
        broadcastConfigToWorkers,
        broadcastGameConfigReload,
        startWorker,
        stopWorker,
        restartWorker,
        callWorkerApi,
        getMergedConnectionStates,
        log,
        addAccountLog,
    };
}

module.exports = {
    createRuntimeEngine,
};
