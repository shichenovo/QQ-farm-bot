/**
 * Code 自动刷新（NapCat 定时兜底层）。
 *
 * 第二层机制：每 60 分钟（可配 FARM_AUTO_REFRESH_MINUTES）无条件对
 * `platform=qq && loginType=napcat_open_auth` 的账号调 bridge /authorize 换新 Code，
 * 写回 store 并重启 worker，避免 Code 静默失效后没被第一层（400 触发）发现。
 *
 * 第一层（失效触发）在 worker-manager 的 ws_error 400 分支，两层的最终调用
 * 都是 napcat-bridge-client 的 authorizeNapCatFarm。
 */

export {};
const { createScheduler } = require('../services/scheduler');
const { authorizeNapCatFarm } = require('../services/napcat-bridge-client');

interface AutoCodeRefreshOptions {
    store: any;
    log: (tag: string, msg: string, extra?: any) => void;
    addAccountLog: (action: string, msg: string, accountId?: string, accountName?: string, extra?: any) => void;
    restartWorker: (account: any) => void;
    getAccounts?: () => any;
}

function createAutoCodeRefreshService(options: AutoCodeRefreshOptions) {
    const {
        store,
        log,
        addAccountLog,
        restartWorker,
    } = options;

    const scheduler = createScheduler('auto_code_refresh');
    const getAccounts = typeof options.getAccounts === 'function' ? options.getAccounts : store.getAccounts;

    const DEFAULT_INTERVAL_MIN = Math.max(1, Math.min(1440, Number(process.env.FARM_AUTO_REFRESH_MINUTES) || 60));

    function getTaskName(accountId: string) {
        return `refresh_${String(accountId || '')}`;
    }

    function findAccount(accountId: string): any {
        const data = getAccounts();
        const accounts = Array.isArray(data && data.accounts) ? data.accounts : [];
        return accounts.find((acc: any) => String(acc.id) === String(accountId)) || null;
    }

    function isNapCatQqAccount(account: any): boolean {
        return !!account
            && String(account.platform || 'qq').toLowerCase() === 'qq'
            && String(account.loginType || '') === 'napcat_open_auth'
            && String(account.uin || account.qq || '').trim() !== '';
    }

    /**
     * 刷新单个账号的 Code。QQ/NapCat 账号走 bridge /authorize；
     * 其它平台（微信等）当前不做自动刷新，返回 false。
     */
    async function refreshAccountCode(accountId: string, reason = 'timer'): Promise<boolean> {
        const account = findAccount(accountId);
        if (!account) return false;

        if (!isNapCatQqAccount(account)) {
            return false;
        }

        const uin = String(account.uin || account.qq || '').trim();
        try {
            const result = await authorizeNapCatFarm(uin, `system:auto-code:${uin}`);
            const authorization = result.authorization || {};
            const profile = result.profile || {};
            if (!authorization.code) throw new Error('QQ 授权未返回农场 Code');
            const boundOpenId = String(account.openID || account.openid || '').trim();
            if (boundOpenId && authorization.openID && authorization.openID !== boundOpenId) {
                throw new Error('QQ 快速登录账号与农场账号不匹配');
            }
            const nextAccount = {
                ...account,
                code: authorization.code,
                openID: authorization.openID || boundOpenId,
                openid: authorization.openID || boundOpenId,
                uin: profile.uin || account.uin || '',
                qq: profile.uin || account.qq || '',
                avatar: profile.avatar || account.avatar || '',
            };
            store.addOrUpdateAccount(nextAccount);
            try {
                restartWorker(nextAccount);
            } catch {}
            addAccountLog('auto_code_refresh', `QQ Code 自动刷新成功，已重启账号: ${account.name || account.id}`,
                account.id, account.name, { reason });
            log('系统', `QQ Code 自动刷新成功: ${account.name || account.id}`, {
                accountId: String(account.id),
                accountName: account.name || '',
            });
            return true;
        } catch (err: any) {
            addAccountLog('auto_code_refresh_failed', `QQ Code 自动刷新失败: ${err.message}`,
                account.id, account.name, { reason });
            log('错误', `QQ Code 自动刷新失败: ${account.name || account.id} - ${err.message}`, {
                accountId: String(account.id),
                accountName: account.name || '',
            });
            return false;
        }
    }

    function scheduleAccount(accountId: string): void {
        const taskName = getTaskName(accountId);
        scheduler.clear(taskName);
        const account = findAccount(accountId);
        if (!account || !isNapCatQqAccount(account)) return;

        scheduler.setIntervalTask(taskName, DEFAULT_INTERVAL_MIN * 60000, () => {
            refreshAccountCode(accountId, 'timer');
        }, { preventOverlap: true });

        log('系统', `NapCat Code 自动刷新已启用: ${account.name || account.id}，间隔 ${DEFAULT_INTERVAL_MIN} 分钟`, {
            accountId: String(accountId),
            accountName: account.name || '',
        });
    }

    function rescheduleAll(): void {
        scheduler.clearAll();
        const data = getAccounts();
        const accounts = Array.isArray(data && data.accounts) ? data.accounts : [];
        for (const account of accounts) {
            scheduleAccount(account.id);
        }
    }

    function stopAccount(accountId: string): void {
        scheduler.clear(getTaskName(accountId));
    }

    return {
        refreshAccountCode,
        scheduleAccount,
        rescheduleAll,
        stopAccount,
    };
}

module.exports = {
    createAutoCodeRefreshService,
};
