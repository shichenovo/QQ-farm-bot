/**
 * 连接监控 + 自动重连
 *
 * 当前 worker-manager 的掉线处理是被动的：只有 worker 主动上报
 * `account_disconnected` / `account_kicked` / `ws_error 400` 才会停掉 worker。
 * 这里加一层**主动监控**：
 *   1. 按周期扫所有 worker 的心跳新鲜度（`status_sync` 距今多久）
 *   2. 通过 `callWorkerApi('ping', ...)` 做一次轻量 RPC，超时则判为「卡死」
 *   3. 状态变化时打点 + 触发 `connection:state` 事件给面板
 *   4. 命中自动重连条件时调用 `restartWorker`，并用指数退避
 *
 * 状态机：
 *   online            — 心跳新鲜 + worker.connection.connected = true
 *   reconnecting      — 自动重连中
 *   no_response       — 心跳/ping 超时
 *   disconnected      — worker 自报掉线
 *   reconnect_failed  — 连续 N 次重连失败
 *   stopped           — 用户主动停止
 */
export {};

const { createScheduler } = require('../services/scheduler');

type ConnectionState = 'online' | 'reconnecting' | 'no_response' | 'disconnected' | 'reconnect_failed' | 'stopped';

interface ConnectionMonitorOptions {
    workers: Record<string, any>;
    restartWorker: (account: any) => void;
    getAccount: (accountId: string) => any;
    callWorkerApi: (accountId: string, method: string, ...args: any[]) => Promise<any>;
    log: (tag: string, msg: string, extra?: any) => void;
    addAccountLog: (action: string, msg: string, accountId?: string, accountName?: string, extra?: any) => void;
    triggerOfflineReminder?: (payload: any) => void;
    onStateChange?: (accountId: string, accountName: string, state: ConnectionState, detail: any) => void;
    options?: {
        heartbeatIntervalMs?: number;     // 心跳巡检周期
        heartbeatStaleMs?: number;       // 多久没收到 status_sync 算 stale
        noResponseTimeoutMs?: number;    // stale 持续多久判 no_response
        pingTimeoutMs?: number;          // ping RPC 超时
        autoReconnect?: boolean;         // 是否启用自动重连
        maxAutoReconnectAttempts?: number;
        baseBackoffMs?: number;          // 指数退避基数
    };
}

function createConnectionMonitor(options: ConnectionMonitorOptions) {
    const cfg = {
        heartbeatIntervalMs: 5_000,
        heartbeatStaleMs: 15_000,
        noResponseTimeoutMs: 30_000,
        pingTimeoutMs: 8_000,
        autoReconnect: true,
        maxAutoReconnectAttempts: 5,
        baseBackoffMs: 3_000,
        ...(options.options || {}),
    };

    const scheduler = createScheduler('connection_monitor');
    const workerState: Record<string, {
        lastStatusSyncAt: number;
        lastPingAt: number;
        lastPingOk: boolean;
        state: ConnectionState;
        reconnectAttempts: number;
        manualStopped: boolean;
        lastDetail: any;
    }> = {};

    function getOrInit(accountId: string) {
        if (!workerState[accountId]) {
            workerState[accountId] = {
                lastStatusSyncAt: 0,
                lastPingAt: 0,
                lastPingOk: false,
                state: 'online',
                reconnectAttempts: 0,
                manualStopped: false,
                lastDetail: null,
            };
        }
        return workerState[accountId];
    }

    function transition(accountId: string, next: ConnectionState, detail: any) {
        const state = getOrInit(accountId);
        if (state.state === next) {
            state.lastDetail = detail;
            return;
        }
        const prev = state.state;
        state.state = next;
        state.lastDetail = detail;
        const account = options.getAccount(accountId);
        const accountName = (account && account.name) || (options.workers[accountId] && options.workers[accountId].name) || accountId;
        if (options.log) {
            const tag = next === 'online' ? '系统' : (next === 'reconnect_failed' ? '错误' : '连接');
            options.log(tag, `[${accountName}] 连接状态 ${prev} -> ${next}${detail?.reason ? ` (${detail.reason})` : ''}`,
                { accountId, accountName, prev, next, detail });
        }
        if (options.addAccountLog && next !== 'online') {
            options.addAccountLog('connection_state', `账号 ${accountName} 连接状态变为 ${next}`,
                accountId, accountName, { prev, next, detail });
        }
        if (options.onStateChange) {
            try {
                options.onStateChange(accountId, accountName, next, { prev, ...detail });
            } catch (e: any) {
                // 监听器抛错不影响主流程
            }
        }
    }

    function markManualStop(accountId: string) {
        const state = getOrInit(accountId);
        state.manualStopped = true;
        transition(accountId, 'stopped', { reason: 'manual_stop' });
    }

    function markWorkerStarted(accountId: string) {
        const state = getOrInit(accountId);
        state.manualStopped = false;
        state.reconnectAttempts = 0;
        state.lastStatusSyncAt = Date.now();
        state.lastPingAt = 0;
        state.lastPingOk = false;
        transition(accountId, 'online', { reason: 'worker_started' });
    }

    function recordStatusSync(accountId: string, status: any) {
        const state = getOrInit(accountId);
        state.lastStatusSyncAt = Date.now();
        const connected = !!(status && status.connection && status.connection.connected);
        if (state.manualStopped) {
            // 用户主动停的，不主动改 state
            return;
        }
        if (connected) {
            // 收到在线心跳就回到 online
            if (state.state !== 'online' && state.state !== 'reconnecting') {
                transition(accountId, 'online', { reason: 'heartbeat_recovered' });
            }
            state.reconnectAttempts = 0;
        }
        else if (state.state !== 'disconnected' && state.state !== 'reconnecting') {
            // worker 自报 connection.connected = false
            transition(accountId, 'disconnected', { reason: 'worker_reported_disconnect', status });
        }
    }

    function recordDisconnected(accountId: string, detail: any) {
        const state = getOrInit(accountId);
        if (state.manualStopped) return;
        transition(accountId, 'disconnected', { reason: 'worker_message', ...detail });
        maybeAutoReconnect(accountId, 'disconnect_message', detail);
    }

    function recordKicked(accountId: string, detail: any) {
        const state = getOrInit(accountId);
        if (state.manualStopped) return;
        // 被踢需要重新登录，不自动重连，标记为 disconnected 即可
        transition(accountId, 'disconnected', { reason: 'kickout', ...detail });
    }

    function maybeAutoReconnect(accountId: string, trigger: string, detail: any) {
        if (!cfg.autoReconnect) return;
        if (trigger === 'kickout') return; // 被踢了不自动重连
        const state = getOrInit(accountId);
        if (state.manualStopped) return;
        if (state.reconnectAttempts >= cfg.maxAutoReconnectAttempts) {
            transition(accountId, 'reconnect_failed', { reason: 'exhausted', trigger, detail });
            return;
        }
        const backoff = Math.min(cfg.baseBackoffMs * Math.pow(2, state.reconnectAttempts), 60_000);
        state.reconnectAttempts += 1;
        transition(accountId, 'reconnecting', { reason: 'auto_reconnect', trigger, attempt: state.reconnectAttempts, backoffMs: backoff, detail });
        scheduler.setTimeoutTask(`reconnect_${accountId}`, backoff, () => {
            const current = options.workers[accountId];
            if (!current) {
                // 进程没了就不重连
                return;
            }
            if (state.manualStopped) return;
            const account = options.getAccount(accountId);
            if (!account) return;
            try {
                options.restartWorker(account);
            } catch (e: any) {
                options.log && options.log('错误', `账号 ${account.name} 自动重连失败: ${e.message}`,
                    { accountId, accountName: account.name, error: e.message });
            }
        });
    }

    async function tick() {
        const now = Date.now();
        for (const [accountId, worker] of Object.entries(options.workers)) {
            const state = getOrInit(accountId);
            if (state.manualStopped) continue;
            if (!worker) continue;
            if (worker.stopping || worker.terminalHandled) continue;

            // 1. 心跳新鲜度
            const lastSync = state.lastStatusSyncAt || 0;
            const staleMs = now - lastSync;
            const isStale = lastSync === 0 || staleMs > cfg.heartbeatStaleMs;

            // 2. 主动 ping（仅在 stale 时才发，避免无谓打扰）
            if (isStale && now - state.lastPingAt > cfg.heartbeatIntervalMs) {
                state.lastPingAt = now;
                try {
                    await Promise.race([
                        options.callWorkerApi(accountId, 'ping').catch(() => null),
                        new Promise(res => setTimeout(res, cfg.pingTimeoutMs)),
                    ]);
                    // 只要 promise settle，就视为「进程还活着」
                    state.lastPingOk = true;
                    // 如果之前是 no_response，且 ping 通了，回到 online
                    if (state.state === 'no_response' || state.state === 'reconnect_failed') {
                        transition(accountId, 'online', { reason: 'ping_recovered' });
                        state.reconnectAttempts = 0;
                    }
                } catch (e: any) {
                    state.lastPingOk = false;
                }
            }

            // 3. stale 持续超过阈值 → no_response
            if (staleMs > cfg.noResponseTimeoutMs) {
                if (state.state === 'online' || state.state === 'reconnecting') {
                    transition(accountId, 'no_response', { reason: 'heartbeat_stale', staleMs });
                }
                if (state.state === 'no_response') {
                    maybeAutoReconnect(accountId, 'no_response', { staleMs });
                }
            }
        }
    }

    function start() {
        if (scheduler.has('heartbeat_tick')) return;
        scheduler.setIntervalTask('heartbeat_tick', cfg.heartbeatIntervalMs, () => {
            tick().catch((e: any) => {
                options.log && options.log('错误', `连接监控 tick 异常: ${e.message}`, { error: e.message });
            });
        });
    }

    function stop() {
        scheduler.clearAll();
    }

    function getState(accountId: string): ConnectionState {
        return getOrInit(accountId).state;
    }

    function getAllStates(): Record<string, { state: ConnectionState; lastStatusSyncAt: number; reconnectAttempts: number; detail: any }> {
        const result: Record<string, any> = {};
        for (const [id, st] of Object.entries(workerState)) {
            result[id] = {
                state: st.state,
                lastStatusSyncAt: st.lastStatusSyncAt,
                reconnectAttempts: st.reconnectAttempts,
                detail: st.lastDetail,
            };
        }
        return result;
    }

    function removeAccount(accountId: string) {
        scheduler.clear(`reconnect_${accountId}`);
        delete workerState[accountId];
    }

    return {
        start,
        stop,
        tick,
        recordStatusSync,
        recordDisconnected,
        recordKicked,
        markManualStop,
        markWorkerStarted,
        getState,
        getAllStates,
        removeAccount,
    };
}

module.exports = {
    createConnectionMonitor,
};
